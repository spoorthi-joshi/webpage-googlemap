from flask import Flask, request, render_template, jsonify
import osmnx as ox
import networkx as nx
import folium

app = Flask(__name__)

# Load the saved Bengaluru graph
graph = ox.load_graphml("bengaluru.graphml")

def get_shortest_path(graph, origin_coords, destination_coords):
    # Find the nearest nodes to the given coordinates
    origin_node = ox.nearest_nodes(graph, origin_coords[1], origin_coords[0])
    destination_node = ox.nearest_nodes(graph, destination_coords[1], destination_coords[0])

    # Compute the shortest path
    shortest_path = nx.shortest_path(graph, origin_node, destination_node, weight="length")
    return shortest_path

def plot_shortest_path(graph, shortest_path, origin_coords, destination_coords):
    # Create a Folium map centered on Bengaluru
    m = folium.Map(location=origin_coords, zoom_start=13, max_bounds=True)

    # Restrict map to Bengaluru's bounding box
    m.fit_bounds([[12.7953, 77.3792], [13.1391, 77.7112]])

    # Add markers for the origin and destination
    folium.Marker(location=origin_coords, popup="Origin", icon=folium.Icon(color="green")).add_to(m)
    folium.Marker(location=destination_coords, popup="Destination", icon=folium.Icon(color="red")).add_to(m)

    # Plot the shortest path
    route_coords = [(graph.nodes[node]["y"], graph.nodes[node]["x"]) for node in shortest_path]
    folium.PolyLine(route_coords, color="blue", weight=5, opacity=0.8).add_to(m)

    return m

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Get coordinates from the form
        if "origin_lat" in request.form and "origin_lon" in request.form:
            origin_lat = float(request.form["origin_lat"])
            origin_lon = float(request.form["origin_lon"])
            dest_lat = float(request.form["dest_lat"])
            dest_lon = float(request.form["dest_lon"])

            # Compute shortest path
            origin_coords = (origin_lat, origin_lon)
            destination_coords = (dest_lat, dest_lon)
            shortest_path = get_shortest_path(graph, origin_coords, destination_coords)
            map_object = plot_shortest_path(graph, shortest_path, origin_coords, destination_coords)

            # Save the map to an HTML file
            map_object.save("templates/map.html")
            return render_template("map.html")

    return render_template("index.html")

@app.route("/map-click", methods=["POST"])
def map_click():
    data = request.get_json()
    origin_coords = data["origin"]
    destination_coords = data["destination"]

    # Compute shortest path
    shortest_path = get_shortest_path(graph, origin_coords, destination_coords)
    map_object = plot_shortest_path(graph, shortest_path, origin_coords, destination_coords)

    # Save the map to an HTML file
    map_object.save("templates/map.html")
    return jsonify({"success": True, "message": "Shortest path computed!"})

if __name__ == "__main__":
    print("Starting Flask app... Visit http://127.0.0.1:5000/ in your browser.")
    app.run(debug=True)
