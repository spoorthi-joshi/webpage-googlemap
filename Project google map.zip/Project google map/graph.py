import osmnx as ox

# Fetch Bengaluru street network
place_name = "Bengaluru, India"
graph = ox.graph_from_place(place_name, network_type="drive")

# Save the graph to a file for later use
ox.save_graphml(graph, "bengaluru.graphml")
